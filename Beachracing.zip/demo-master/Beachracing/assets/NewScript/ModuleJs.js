


var GameValue = {
   

    CoinNumOfPurch: {//金币购买次数
        coin1: -1,
        coin2: -1,
        coin3: -1,
        coin4: -1,
        coin5: -1,
        coin6: -1,
        coin7: -1,
        coin8: -1,
        coin9: -1,
    },
};


module.exports = GameValue