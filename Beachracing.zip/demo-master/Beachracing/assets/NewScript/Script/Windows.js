module.exports = {
    coinTotalLabel: 10000000,
    carDeblockWindow:0
}